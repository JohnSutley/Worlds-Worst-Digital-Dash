<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="world2-tileset" tilewidth="8" tileheight="8" tilecount="112" columns="14">
 <image source="world2-tileset.png" trans="ff00ff" width="112" height="64"/>
</tileset>
