#ifndef __VERSION_H_INCLUDE__
#define __VERSION_H_INCLUDE__

#define __GBDK_VERSION 430

#endif
